/**
 * Single source of truth for site-wide values.
 *
 * The PRD wants the USSD short-code, channel list and loan terms to be
 * editable without a redeploy. Today they live here; when the CMS is wired in,
 * replace the exports with a fetch (ISR / on-demand revalidation) and keep the
 * same shape so no component needs to change.
 */

export type MediaSlot = {
  /** Still image. Also used as the video poster. */
  src: string;
  alt: string;
  /** Optional looping / story video (MP4 H.264). Keep hero loops under ~1.5 MB. */
  video?: string;
  videoWebm?: string;
  /** Art-direction note, shown only in development when the file is missing. */
  brief: string;
};

export const siteConfig = {
  name: "KINLEND",
  description:
    "Loans without collateral for Nigerian traders, artisans and farmers. A KinMaster who knows you vouches for you. Repay on any phone and get an SMS receipt every time.",
  // TODO: confirm domain (PRD open question 2)
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://kinlend.com",

  ussd: {
    /** The one place the short-code is defined. Shared in the pilot, dedicated at scale. */
    code: "*746#",
    kind: "shared" as "shared" | "dedicated",
  },

  whatsapp: {
    // International format, digits only. TODO: confirm the KINLEND business number.
    number: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "2340000000000",
    prefill: "Hello KINLEND, I would like to know how to get started.",
  },

  /**
   * Primary navigation points at on-page sections while only the landing page
   * exists. Swap each href for the real route as its page ships.
   */
  nav: [
    { label: "How it works", href: "#how-it-works" },
    { label: "For borrowers", href: "#ladder" },
    { label: "For KinMasters", href: "#kinmasters" },
    { label: "Impact", href: "#stories" },
    { label: "Partners & investors", href: "#partners" },
  ],

  /** Routes for pages that are not built yet. They will 404 until each page ships. */
  routes: {
    findKinMaster: "/find-a-kinmaster",
    howItWorks: "/how-it-works",
    becomeKinMaster: "/kinmasters/apply",
    kinMasterLogin: process.env.NEXT_PUBLIC_KINMASTER_PORTAL_URL ?? "/kinmasters/login",
    investors: "/partners/investors",
    cooperatives: "/partners/cooperatives",
    blog: "/resources",
    faq: "/faq",
    about: "/about",
    careers: "/careers",
    contact: "/contact",
    privacy: "/legal/privacy",
    terms: "/legal/terms",
  },

  /**
   * Media slots. Drop files into /public/media with these names (or change the
   * paths). Until a file exists, the page shows a labelled placeholder in dev
   * and a plain brand-colour panel in production.
   */
  media: {
    hero: {
      src: "/media/hero-market.jpg",
      video: "/media/hero-market.mp4",
      videoWebm: "/media/hero-market.webm",
      alt: "A trader arranging goods at her market stall",
      brief:
        "Portrait 4:5. Real trader at her stall, natural light, looking at camera or at her phone. Loop: 6 to 8 s, 480p, no audio, under 1.5 MB.",
    },
    vouch: {
      src: "/media/kinmaster-vouching.jpg",
      alt: "A KinMaster meeting a borrower at her shop to vet her in person",
      brief:
        "Portrait 4:5. A KinMaster and a borrower talking in the borrower's own shop or stall. Candid, warm, two people at eye level.",
    },
    kinmaster: {
      src: "/media/kinmaster-portrait.jpg",
      alt: "A KinMaster standing in her community market",
      brief:
        "Portrait 4:5. A respected local figure, dignified, in their own environment. No stock-photo handshakes.",
    },
    story: {
      src: "/media/story-poster.jpg",
      video: "/media/story.mp4",
      videoWebm: "/media/story.webm",
      alt: "A KINLEND borrower tells her story",
      brief:
        "16:10 or 4:5 poster frame of a consented borrower video (a WhatsApp clip is fine). Captions burned in. Keep under 6 MB.",
    },
  } satisfies Record<string, MediaSlot>,

  /**
   * Repayment channels shown on the site. Providers roll out in phases, so
   * only mark a channel "live" once it works end to end.
   * TODO: confirm go-live channels (PRD open question 3).
   */
  channels: [
    { id: "ussd", name: "USSD short-code", note: "Works on any phone, with no data.", status: "live" },
    { id: "momo", name: "Mobile money", note: "Pay from your mobile money wallet.", status: "soon" },
    { id: "pos", name: "POS and agency banking", note: "Pay at a bank agent, straight to KINLEND.", status: "soon" },
    { id: "bank", name: "Bank transfer", note: "Send to KINLEND's account from any bank.", status: "soon" },
  ] as { id: string; name: string; note: string; status: "live" | "soon" }[],

  compliance: {
    ndpa: "We handle your data under the Nigeria Data Protection Act (NDPA) and ask for your consent first.",
    /**
     * Licensing and fee-transparency statements required on money-touching
     * pages. Compliance supplies these (PRD open question 6). Empty = not shown.
     */
    disclosures: [] as string[],
  },
};

/** `tel:` link for the USSD code. The # must be percent-encoded. */
export const ussdDialHref = (code: string = siteConfig.ussd.code) =>
  `tel:${code.replace(/#/g, "%23")}`;

export const whatsappHref = (text: string = siteConfig.whatsapp.prefill) =>
  `https://wa.me/${siteConfig.whatsapp.number}?text=${encodeURIComponent(text)}`;
