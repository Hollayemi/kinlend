"use client";

import Link from "next/link";
import { useState } from "react";
import { AnimatePresence, m, useMotionValueEvent, useScroll } from "framer-motion";
import { Menu, MessageCircle, X } from "lucide-react";
import { siteConfig, ussdDialHref, whatsappHref } from "@/config/site";
import { collapseMotion } from "@/lib/motion";
import { cn } from "@/lib/cn";
import { Container } from "@/components/ui/Container";
import { Logo } from "@/components/ui/Logo";
import { ButtonLink } from "@/components/ui/ButtonLink";
import { ApplyRepayButton } from "@/components/ussd/ApplyRepayButton";

export function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { scrollY } = useScroll();
  useMotionValueEvent(scrollY, "change", (v) => setScrolled(v > 8));

  const code = siteConfig.ussd.code;

  return (
    <>
      {/* Slim strip: the USSD code is always visible, even before anything loads. */}
      <div className="bg-ter-900 text-white">
        <Container className="flex h-9 items-center justify-between text-[0.8125rem]">
          <p>
            Apply or repay on any phone: dial{" "}
            <a href={ussdDialHref()} className="font-mono font-semibold tracking-wide underline-offset-2 hover:underline">
              {code}
            </a>
          </p>
          <ButtonLink
            href={whatsappHref()}
            variant="ghost"
            size="sm"
            event="whatsapp_click"
            eventProps={{ location: "top-strip" }}
            className="hidden !h-auto gap-1.5 !px-0 !py-0 text-white hover:bg-transparent hover:underline sm:inline-flex"
          >
            <MessageCircle className="h-3.5 w-3.5" />
            Chat on WhatsApp
          </ButtonLink>
        </Container>
      </div>

      <header className={cn("sticky top-0 z-40 border-b transition-colors duration-200", scrolled || open ? "border-neu-200 bg-neu-50/95" : "border-transparent bg-neu-50")}>
        <Container className="flex h-16 items-center justify-between gap-6 lg:h-[4.5rem]">
          <Link href="/" aria-label="KINLEND home" className="rounded-md">
            <Logo />
          </Link>

          <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
            {siteConfig.nav.map((item) => (
              <a key={item.href} href={item.href} className="rounded-md px-3 py-2 text-[0.9375rem] font-medium text-neu-700 transition-colors hover:bg-neu-100 hover:text-neu-900">
                {item.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <ApplyRepayButton placement="bottom-end" size="md" source="header" className="hidden sm:inline-block" />
            <button
              type="button"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              aria-controls="mobile-menu"
              onClick={() => setOpen((o) => !o)}
              className="grid h-11 w-11 place-items-center rounded-lg text-neu-900 hover:bg-neu-100 lg:hidden"
            >
              {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </Container>

        <AnimatePresence initial={false}>
          {open && (
            <m.div id="mobile-menu" {...collapseMotion} className="overflow-hidden border-t border-neu-200 lg:hidden">
              <Container className="py-4">
                <nav aria-label="Mobile" className="flex flex-col">
                  {siteConfig.nav.map((item) => (
                    <a
                      key={item.href}
                      href={item.href}
                      onClick={() => setOpen(false)}
                      className="border-b border-neu-200 py-3.5 font-display text-xl font-semibold text-neu-900 last:border-b-0"
                    >
                      {item.label}
                    </a>
                  ))}
                </nav>
                <div className="mt-4 flex flex-col gap-2 sm:hidden">
                  <ButtonLink href={siteConfig.routes.findKinMaster} variant="secondary" size="lg" event="find_kinmaster_click" eventProps={{ location: "mobile-menu" }}>
                    Find a KinMaster
                  </ButtonLink>
                </div>
              </Container>
            </m.div>
          )}
        </AnimatePresence>
      </header>
    </>
  );
}
