import { MapPin } from "lucide-react";
import { siteConfig, ussdDialHref } from "@/config/site";
import { Container } from "@/components/ui/Container";
import { ButtonLink } from "@/components/ui/ButtonLink";
import { Media } from "@/components/ui/Media";
import { TextReveal } from "@/components/motion/TextReveal";
import { ApplyRepayButton } from "@/components/ussd/ApplyRepayButton";
import { UssdCodeLoader } from "@/components/ussd/UssdCodeLoader";

/**
 * Everything on the left is CSS-animated so it paints immediately on a slow
 * connection. The photo/video on the right is the only heavy asset.
 */
export function Hero() {
  return (
    <section className="relative overflow-hidden bg-neu-50">
      <Container className="grid gap-12 pb-16 pt-8 lg:grid-cols-12 lg:gap-14 lg:pb-24 lg:pt-16">
        <div className="lg:col-span-7 lg:pt-4">
          <p className="eyebrow animate-fade-up text-pri-700" style={{ animationDelay: "60ms" }}>
            Loans for traders, artisans and farmers
          </p>

          <TextReveal
            text="No collateral. Your community vouches for you."
            emphasis={["community", "vouches"]}
            delay={120}
            className="mt-5 font-display text-[2.75rem] font-semibold leading-[1.02] text-neu-900 sm:text-[4rem] lg:text-[4.75rem]"
          />

          <p className="mt-7 max-w-[34rem] animate-fade-up text-[1.1875rem] leading-relaxed text-neu-700" style={{ animationDelay: "620ms" }}>
            A loan approved by people who know you. Repaid on any phone, with an SMS receipt in your hand every time.
          </p>

          <div className="mt-9 flex animate-fade-up flex-col gap-3 sm:flex-row sm:items-center" style={{ animationDelay: "760ms" }}>
            <ApplyRepayButton placement="bottom-start" size="lg" source="hero" />
            <ButtonLink href={siteConfig.routes.findKinMaster} variant="secondary" size="lg" event="find_kinmaster_click" eventProps={{ location: "hero" }}>
              <MapPin className="h-4 w-4" />
              Find a KinMaster
            </ButtonLink>
          </div>

          <p className="mt-6 animate-fade-up text-sm text-neu-600" style={{ animationDelay: "880ms" }}>
            No smartphone? No data? Dial{" "}
            <a href={ussdDialHref()} className="font-mono font-semibold text-ter-700 underline underline-offset-2">
              {siteConfig.ussd.code}
            </a>{" "}
            from any phone.
          </p>
        </div>

        <div className="relative lg:col-span-5">
          <div aria-hidden className="absolute inset-0 translate-x-3 translate-y-3 rounded-[1.25rem] border border-pri-600/40" />
          <div className="relative aspect-[4/5] overflow-hidden rounded-[1.25rem] bg-pri-900 shadow-card">
            <Media slot={siteConfig.media.hero} priority sizes="(min-width: 1024px) 38vw, 100vw" tone="pri" />
            <div aria-hidden className="absolute inset-x-0 bottom-0 h-2/5 bg-gradient-to-t from-neu-900/80 to-transparent" />

            <div className="absolute inset-x-4 bottom-4 flex items-end justify-between gap-4 rounded-xl bg-neu-900/90 p-4 text-white">
              <div>
                <p className="text-xs font-medium text-white/70">Dial on any phone</p>
                <UssdCodeLoader size="lg" tone="light" className="mt-2" />
              </div>
              <p className="hidden max-w-[9rem] text-right text-xs leading-snug text-white/70 min-[420px]:block">
                Vetted by a KinMaster. Approved by KINLEND.
              </p>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
