"use client";

import { useState } from "react";
import { MapPin } from "lucide-react";
import { ussdStages } from "@/config/content";
import { siteConfig } from "@/config/site";
import { cn } from "@/lib/cn";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { ButtonLink } from "@/components/ui/ButtonLink";
import { Reveal } from "@/components/motion/Reveal";
import { PhoneDialDemo } from "@/components/ussd/PhoneDialDemo";
import { UssdCodeLoader } from "@/components/ussd/UssdCodeLoader";

export function UssdDemo() {
  const code = siteConfig.ussd.code;
  const [stage, setStage] = useState(0);
  const [jump, setJump] = useState<{ stage: number; nonce: number } | null>(null);

  return (
    <section id="ussd" className="relative scroll-mt-24 overflow-hidden bg-ter-900 py-20 text-white lg:py-28">
      {/* Concentric rings behind the phone */}
      <svg aria-hidden viewBox="0 0 800 800" className="pointer-events-none absolute -right-48 top-1/2 hidden h-[52rem] w-[52rem] -translate-y-1/2 lg:block">
        {[120, 200, 280, 360, 440].map((r) => (
          <circle key={r} cx="400" cy="400" r={r} fill="none" stroke="white" strokeOpacity={0.08} />
        ))}
      </svg>

      <Container className="relative grid items-center gap-14 lg:grid-cols-12">
        <div className="lg:col-span-6">
          <SectionHeading
            tone="ter"
            onDark
            eyebrow="Built for any phone"
            title="Repay from any phone. No data. No app."
            body="If it works on a feature phone with one bar of signal, it works for everyone. Here is the whole thing, start to finish."
          />

          <Reveal className="mt-9">
            <p className="text-sm font-medium text-white/70">Your code</p>
            <UssdCodeLoader size="xl" tone="light" className="mt-2" />
          </Reveal>

          <Reveal as="ol" className="mt-10 space-y-1" aria-label="The four steps">
            {ussdStages.map((s, i) => {
              const active = stage === i;
              return (
                <li key={s.title}>
                  <button
                    type="button"
                    aria-current={active ? "step" : undefined}
                    onClick={() => setJump({ stage: i, nonce: Date.now() })}
                    className={cn(
                      "flex w-full gap-4 border-l-2 py-3 pl-5 pr-3 text-left transition-colors duration-300",
                      active ? "border-white bg-white/5" : "border-white/15 hover:border-white/40",
                    )}
                  >
                    <span className={cn("font-mono text-sm font-semibold tabular-nums", active ? "text-white" : "text-ter-300")}>0{i + 1}</span>
                    <span>
                      <span className={cn("block text-lg font-semibold transition-colors", active ? "text-white" : "text-ter-200")}>{s.title}</span>
                      <span className={cn("mt-0.5 block text-[0.9375rem] leading-relaxed transition-colors", active ? "text-white/85" : "text-ter-300")}>
                        {s.body.replace("{code}", code)}
                      </span>
                    </span>
                  </button>
                </li>
              );
            })}
          </Reveal>

          <Reveal className="mt-10 rounded-xl border border-white/15 p-5">
            <p className="text-[0.9375rem] leading-relaxed text-white/85">
              <strong className="font-semibold text-white">Only vetted borrowers can transact.</strong> A KinMaster has met you in person and KINLEND has approved you. That is a safety feature, not a barrier.
            </p>
            <ButtonLink
              href={siteConfig.routes.findKinMaster}
              variant="onDark"
              size="md"
              event="find_kinmaster_click"
              eventProps={{ location: "ussd-demo" }}
              className="mt-4"
            >
              <MapPin className="h-4 w-4" />
              Find a KinMaster to get started
            </ButtonLink>
          </Reveal>
        </div>

        <Reveal scale className="lg:col-span-6">
          <PhoneDialDemo onStageChange={setStage} jump={jump} />
          <p className="mt-6 text-center text-xs text-ter-300">Illustration. Names and amounts are examples.</p>
        </Reveal>
      </Container>
    </section>
  );
}
