import { cn } from "@/lib/cn";

/**
 * Placeholder mark: three overlapping circles in the brand trio (mission,
 * community, money). Replace with the supplied logo file when it arrives.
 */
export function LogoMark({ className, onDark = false }: { className?: string; onDark?: boolean }) {
  const blend = onDark ? "screen" : "multiply";
  const c = onDark ? ["var(--color-pri-400)", "var(--color-sec-400)", "var(--color-ter-400)"] : ["var(--color-pri-600)", "var(--color-sec-600)", "var(--color-ter-600)"];
  return (
    <svg viewBox="0 0 32 32" aria-hidden className={cn("h-8 w-8", className)} style={{ isolation: "isolate" }}>
      <circle cx="12" cy="12.5" r="8" fill={c[0]} style={{ mixBlendMode: blend }} />
      <circle cx="20" cy="12.5" r="8" fill={c[1]} style={{ mixBlendMode: blend }} />
      <circle cx="16" cy="20" r="8" fill={c[2]} style={{ mixBlendMode: blend }} />
    </svg>
  );
}

export function Logo({ onDark = false, className }: { onDark?: boolean; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <LogoMark onDark={onDark} />
      <span className={cn("font-display text-[1.4rem] font-bold leading-none tracking-[0.01em]", onDark ? "text-white" : "text-neu-900")}>KINLEND</span>
    </span>
  );
}
