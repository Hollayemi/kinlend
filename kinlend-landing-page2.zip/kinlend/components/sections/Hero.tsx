import { MapPin } from "lucide-react";
import { siteConfig, ussdDialHref } from "@/config/site";
import { Container } from "@/components/ui/Container";
import { ButtonLink } from "@/components/ui/ButtonLink";
import { TextReveal } from "@/components/motion/TextReveal";
import { ApplyRepayButton } from "@/components/ussd/ApplyRepayButton";
import { HeroSlides } from "./HeroSlides";
import { HeroPhone } from "./HeroPhone";

/**
 * Full-screen hero. The (transparent) header sits on top of it. Headline and
 * copy are CSS-animated so they paint at once on a slow connection; the phone
 * slides up on load and runs the USSD walkthrough.
 */
export function Hero() {
  return (
    <section className="relative isolate overflow-hidden text-white">
      <HeroSlides />

      <Container className="relative z-10 grid min-h-[100svh] items-center gap-12 pb-24 pt-28 lg:grid-cols-12 lg:gap-8 lg:pb-16 lg:pt-28">
        <div className="lg:col-span-7">
          <p className="eyebrow animate-fade-up text-pri-200" style={{ animationDelay: "60ms" }}>
            Loans for traders, artisans and farmers
          </p>

          <TextReveal
            text="No collateral. Your community vouches for you."
            emphasis={["community", "vouches"]}
            emphasisClassName="text-acc-300"
            delay={120}
            className="mt-5 text-[2.6rem] font-extrabold leading-[1.04] text-white sm:text-[3.6rem] lg:text-[4.25rem]"
          />

          <p className="mt-7 max-w-[32rem] animate-fade-up text-[1.1875rem] leading-relaxed text-white/85" style={{ animationDelay: "620ms" }}>
            A loan approved by people who know you. Repaid on any phone, with an SMS receipt in your hand every time.
          </p>

          <div className="mt-9 flex animate-fade-up flex-col gap-3 sm:flex-row sm:items-center" style={{ animationDelay: "760ms" }}>
            <ApplyRepayButton placement="bottom-start" size="lg" variant="onDark" source="hero" />
            <ButtonLink href={siteConfig.routes.findKinMaster} variant="onDarkOutline" size="lg" event="find_kinmaster_click" eventProps={{ location: "hero" }}>
              <MapPin className="h-4 w-4" />
              Find a KinMaster
            </ButtonLink>
          </div>

          <p className="mt-6 animate-fade-up text-sm text-white/75" style={{ animationDelay: "880ms" }}>
            No smartphone? No data? Dial{" "}
            <a href={ussdDialHref()} className="font-mono font-semibold text-white underline underline-offset-2">
              {siteConfig.ussd.code}
            </a>{" "}
            from any phone.
          </p>
        </div>

        <div className="lg:col-span-5 lg:justify-self-center">
          <HeroPhone />
        </div>
      </Container>
    </section>
  );
}
