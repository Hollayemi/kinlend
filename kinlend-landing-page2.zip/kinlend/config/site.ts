/**
 * Single source of truth for site-wide values.
 *
 * The PRD wants the USSD short-code, channel list and loan terms to be
 * editable without a redeploy. Today they live here; when the CMS is wired in,
 * replace the exports with a fetch (ISR / on-demand revalidation) and keep the
 * same shape so no component needs to change.
 */

export type HeroSlide = MediaSlot & {
  /** Short caption shown beside the slide dots. */
  label: string;
  /** Colour of the placeholder panel while the photo is missing. */
  tone: "pri" | "sec" | "ter";
};

export type MediaSlot = {
  /** Still image. Also used as the video poster. */
  src: string;
  alt: string;
  /** Optional looping / story video (MP4 H.264). Keep hero loops under ~1.5 MB. */
  video?: string;
  videoWebm?: string;
  /** Art-direction note, shown only in development when the file is missing. */
  brief: string;
};

export const siteConfig = {
  name: "KINLEND",
  description:
    "Loans without collateral for Nigerian traders, artisans and farmers. A KinMaster who knows you vouches for you. Repay on any phone and get an SMS receipt every time.",
  // TODO: confirm domain (PRD open question 2)
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://kinlend.com",

  ussd: {
    /** The one place the short-code is defined. Shared in the pilot, dedicated at scale. */
    code: "*746#",
    kind: "shared" as "shared" | "dedicated",
  },

  whatsapp: {
    // International format, digits only. TODO: confirm the KINLEND business number.
    number: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "2340000000000",
    prefill: "Hello KINLEND, I would like to know how to get started.",
  },

  /**
   * Primary navigation points at on-page sections while only the landing page
   * exists. Swap each href for the real route as its page ships.
   */
  nav: [
    { label: "How it works", href: "#how-it-works" },
    { label: "For borrowers", href: "#ladder" },
    { label: "For KinMasters", href: "#kinmasters" },
    { label: "Impact", href: "#stories" },
    { label: "Partners & investors", href: "#partners" },
  ],

  /** Routes for pages that are not built yet. They will 404 until each page ships. */
  routes: {
    findKinMaster: "/find-a-kinmaster",
    howItWorks: "/how-it-works",
    becomeKinMaster: "/kinmasters/apply",
    kinMasterLogin: process.env.NEXT_PUBLIC_KINMASTER_PORTAL_URL ?? "/kinmasters/login",
    investors: "/partners/investors",
    cooperatives: "/partners/cooperatives",
    blog: "/resources",
    faq: "/faq",
    about: "/about",
    careers: "/careers",
    contact: "/contact",
    privacy: "/legal/privacy",
    terms: "/legal/terms",
  },

  /**
   * Media slots. Drop files into /public/media with these names (or change the
   * paths). Until a file exists, the page shows a labelled placeholder in dev
   * and a plain brand-colour panel in production.
   */
  media: {
    vouch: {
      src: "/media/kinmaster-vouching.jpg",
      alt: "A KinMaster meeting a borrower at her shop to vet her in person",
      brief:
        "Portrait 4:5. A KinMaster and a borrower talking in the borrower's own shop or stall. Candid, warm, two people at eye level.",
    },
    kinmaster: {
      src: "/media/kinmaster-portrait.jpg",
      alt: "A KinMaster standing in her community market",
      brief:
        "Portrait 4:5. A respected local figure, dignified, in their own environment. No stock-photo handshakes.",
    },
    story: {
      src: "/media/story-poster.jpg",
      video: "/media/story.mp4",
      videoWebm: "/media/story.webm",
      alt: "A KINLEND borrower tells her story",
      brief:
        "16:10 or 4:5 poster frame of a consented borrower video (a WhatsApp clip is fine). Captions burned in. Keep under 6 MB.",
    },
  } satisfies Record<string, MediaSlot>,

  /**
   * Full-bleed photos that slide behind the hero. Landscape 16:9, at least
   * 1920 px wide, under ~350 KB each (compress to WebP/JPEG q70). Keep the
   * subject in the middle or lower third: the left side sits under the headline
   * and a dark green overlay is applied on top.
   */
  heroSlides: [
    { src: "/media/hero-1-trader.jpg", alt: "A trader arranging goods at her market stall", label: "Market traders", tone: "pri", brief: "Landscape 16:9. Trader at her stall, natural light, candid." },
    { src: "/media/hero-2-artisan.jpg", alt: "A tailor at work in her workshop", label: "Artisans", tone: "sec", brief: "Landscape 16:9. Tailor, welder or weaver at work in a real workshop." },
    { src: "/media/hero-3-farmer.jpg", alt: "A farmer in her field", label: "Smallholder farmers", tone: "ter", brief: "Landscape 16:9. Farmer on her land, harvest or produce in hand." },
    { src: "/media/hero-4-cooperative.jpg", alt: "Members of a women's savings group meeting", label: "Cooperatives and savings groups", tone: "pri", brief: "Landscape 16:9. A women's ajo/esusu group meeting, faces visible, with consent." },
  ] satisfies HeroSlide[],

  /**
   * Repayment channels shown on the site. Providers roll out in phases, so
   * only mark a channel "live" once it works end to end.
   * TODO: confirm go-live channels (PRD open question 3).
   */
  channels: [
    { id: "ussd", name: "USSD short-code", note: "Works on any phone, with no data.", status: "live" },
    { id: "momo", name: "Mobile money", note: "Pay from your mobile money wallet.", status: "soon" },
    { id: "pos", name: "POS and agency banking", note: "Pay at a bank agent, straight to KINLEND.", status: "soon" },
    { id: "bank", name: "Bank transfer", note: "Send to KINLEND's account from any bank.", status: "soon" },
  ] as { id: string; name: string; note: string; status: "live" | "soon" }[],

  compliance: {
    ndpa: "We handle your data under the Nigeria Data Protection Act (NDPA) and ask for your consent first.",
    /**
     * Licensing and fee-transparency statements required on money-touching
     * pages. Compliance supplies these (PRD open question 6). Empty = not shown.
     */
    disclosures: [] as string[],
  },
};

/** `tel:` link for the USSD code. The # must be percent-encoded. */
export const ussdDialHref = (code: string = siteConfig.ussd.code) =>
  `tel:${code.replace(/#/g, "%23")}`;

export const whatsappHref = (text: string = siteConfig.whatsapp.prefill) =>
  `https://wa.me/${siteConfig.whatsapp.number}?text=${encodeURIComponent(text)}`;
