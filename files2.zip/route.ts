/**
 * Lead intake for the website: investor and partner enquiries, and KinMaster
 * applications. The site only ever *forwards* leads (PRD section 7); storage,
 * vetting and acknowledgements live in the KINLEND backend / CRM.
 *
 * Configure on the server (never NEXT_PUBLIC_):
 *   LEADS_WEBHOOK_URL    where to POST the JSON lead (CRM, Zapier, backend)
 *   LEADS_WEBHOOK_TOKEN  optional bearer token sent with the request
 *
 * Without LEADS_WEBHOOK_URL this returns 503 and the forms fall back to
 * WhatsApp / email. Nothing is stored or logged here.
 */

const TYPES = new Set(["investor", "partner", "kinmaster_application"]);
const MAX_BYTES = 20_000;

// Best-effort limiter. In-memory, so per server instance: put a real limiter
// (edge / WAF / Redis) in front before launch.
const hits = new Map<string, number[]>();
const WINDOW_MS = 60 * 60 * 1000;
const LIMIT = 8;

function limited(ip: string) {
  const now = Date.now();
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW_MS);
  recent.push(now);
  hits.set(ip, recent);
  return recent.length > LIMIT;
}

const json = (body: unknown, status: number) => Response.json(body, { status, headers: { "cache-control": "no-store" } });

export async function POST(request: Request) {
  const webhook = process.env.LEADS_WEBHOOK_URL;
  if (!webhook) return json({ error: "not_configured" }, 503);

  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  if (limited(ip)) return json({ error: "rate_limited" }, 429);

  const raw = await request.text();
  if (raw.length > MAX_BYTES) return json({ error: "too_large" }, 413);

  let body: { type?: unknown; data?: unknown };
  try {
    body = JSON.parse(raw);
  } catch {
    return json({ error: "bad_request" }, 400);
  }

  const { type, data } = body;
  if (typeof type !== "string" || !TYPES.has(type) || typeof data !== "object" || data === null || Array.isArray(data)) {
    return json({ error: "bad_request" }, 400);
  }

  const fields = data as Record<string, unknown>;
  // Honeypot: real people never fill the hidden "website" field. Pretend success to bots.
  if (typeof fields.website === "string" && fields.website.trim() !== "") return json({ ok: true }, 202);

  // Keep only flat string / boolean fields.
  const clean: Record<string, string | boolean> = {};
  for (const [k, v] of Object.entries(fields)) {
    if (k === "website") continue;
    if (typeof v === "string") clean[k] = v.slice(0, 2000);
    else if (typeof v === "boolean") clean[k] = v;
  }

  try {
    const res = await fetch(webhook, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        ...(process.env.LEADS_WEBHOOK_TOKEN ? { authorization: `Bearer ${process.env.LEADS_WEBHOOK_TOKEN}` } : {}),
      },
      body: JSON.stringify({ type, data: clean, receivedAt: new Date().toISOString(), source: "kinlend-web" }),
    });
    if (!res.ok) return json({ error: "upstream_failed" }, 502);
  } catch {
    return json({ error: "upstream_failed" }, 502);
  }

  return json({ ok: true }, 202);
}
